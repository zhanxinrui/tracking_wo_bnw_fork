from setuptools import setup, find_packages

setup(name='fpn',
      packages=['fpn'],
      package_dir={'fpn':'fpn'},)
